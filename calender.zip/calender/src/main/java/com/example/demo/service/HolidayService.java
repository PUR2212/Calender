package com.example.demo.service;

import com.example.demo.models.HolidayDays;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.*;

@Service
public class HolidayService {

    public List<HolidayDays> findHolidays(LocalDate startDate, LocalDate endDate) {
    try {
        List<HolidayDays> result = new ArrayList<>();
        Map<Integer, List<LocalDate>> weekToWeekdayHolidays = new HashMap<>();
        WeekFields weekFields = WeekFields.ISO;

        // Step 1: Track weekday holidays per week
        for (LocalDate holiday : predefinedHolidays) {
            DayOfWeek day = holiday.getDayOfWeek();
            if (day.getValue() >= 1 && day.getValue() <= 5) { // Mon-Fri
                int weekNum = holiday.get(weekFields.weekOfWeekBasedYear());
                weekToWeekdayHolidays
                        .computeIfAbsent(weekNum, k -> new ArrayList<>())
                        .add(holiday);
            }
        }

        // Step 2: Generate entries for each date
        for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
            boolean isHoliday = predefinedHolidays.contains(date);
            int weekNum = date.get(weekFields.weekOfWeekBasedYear());
            boolean allWeekdaysAreHolidays = weekToWeekdayHolidays.getOrDefault(weekNum, List.of()).size() >= 5;

            String color = (allWeekdaysAreHolidays && isHoliday) ? "green" : "white";

            result.add(new HolidayDays(date, isHoliday, color));
        }

        return result;
    }catch(Exception e){
        e.printStackTrace();
        return new ArrayList<>();
    }
    }
    private static final Set<LocalDate> predefinedHolidays = Set.of(
            // Week with all weekdays as holidays (e.g., July 7–11)
            LocalDate.of(2025, 7, 7),
            LocalDate.of(2025, 7, 8),
            LocalDate.of(2025, 7, 9),
            LocalDate.of(2025, 7, 10),
            LocalDate.of(2025, 7, 11),
            // Random other holidays
            LocalDate.of(2025, 6, 17),
            LocalDate.of(2025, 8, 15)
    );
}
