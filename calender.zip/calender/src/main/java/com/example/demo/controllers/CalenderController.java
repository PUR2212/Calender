package com.example.demo.controllers;

import com.example.demo.models.HolidayDays;
import com.example.demo.service.HolidayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/holiday")
public class CalenderController {

@Autowired
    HolidayService holidayService;

    @GetMapping("/holidays")
    public  List<HolidayDays> getHolidays() throws Exception {

        LocalDate start = LocalDate.of(2025, 6, 1);
        LocalDate end = start.plusMonths(3).minusDays(1);


        List<HolidayDays>holidays  =holidayService.findHolidays(start, end);
        return holidays;
    }

    @GetMapping("/vacation")
    public  List<HolidayDays> getVacationHolidays() throws Exception {
        LocalDate start = LocalDate.of(2025, 6, 1);
        LocalDate end = start.plusMonths(3).minusDays(1);


        List<HolidayDays>holidays  =holidayService.findHolidays(start, end);
        return holidays;
    }

    @GetMapping("/greeting")
    public Model greeting(Model model) {
        model.addAttribute("message", "Hello from Spring Boot!");
        model.addAttribute("year", 2025);
        return model;
//        return "greeting"; // returns greeting.html from /templates
    }






}
