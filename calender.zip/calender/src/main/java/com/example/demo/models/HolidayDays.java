package com.example.demo.models;

import lombok.Data;

import java.time.LocalDate;
import java.util.Date;


public class HolidayDays {

    private LocalDate date;
    private Boolean holiday;

    private String colour;



    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Boolean getHoliday() {
        return holiday;
    }

    public void setHoliday(Boolean holiday) {
        this.holiday = holiday;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public HolidayDays(LocalDate date, Boolean holiday, String colour) {
        this.date = date;
        this.holiday = holiday;
        this.colour = colour;
    }
}
