package com.example.demo.service;

import com.example.demo.models.HolidayDays;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class HolidayService {

    public List<HolidayDays> findHolidays(LocalDate startDate, LocalDate endDate) {
        try {
            List<HolidayDays> result = new ArrayList<>();
            Map<Integer, List<LocalDate>> weekToHolidays = new HashMap<>();
            WeekFields weekFields = WeekFields.ISO;

            // Step 1: Group all holidays by week number (regardless of weekday/weekend)
            for (LocalDate holiday : predefinedHolidays) {
                int weekNum = holiday.get(weekFields.weekOfWeekBasedYear());
                weekToHolidays
                        .computeIfAbsent(weekNum, k -> new ArrayList<>())
                        .add(holiday);
            }

            // Step 2: Identify weeks with more than one holiday
            Set<Integer> darkGreenWeeks = weekToHolidays.entrySet().stream()
                    .filter(e -> e.getValue().size() > 1)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toSet());

            // Step 3: Generate HolidayDays entries for each date
            for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
                boolean isHoliday = predefinedHolidays.contains(date);
                int weekNum = date.get(weekFields.weekOfWeekBasedYear());

                String color;
                if (darkGreenWeeks.contains(weekNum)) {
                    color = "darkgreen";  // Entire week gets dark green
                } else if (isHoliday) {
                    color = "red";        // Single holiday
                } else {
                    color = "green";      // Regular working day
                }

                result.add(new HolidayDays(date, isHoliday, color));
            }

            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    private static final Set<LocalDate> predefinedHolidays = Set.of(
            // Week with all weekdays as holidays (e.g., July 7–11)
            LocalDate.of(2025, 7, 7),
            LocalDate.of(2025, 7, 8),
            LocalDate.of(2025, 7, 9),
            LocalDate.of(2025, 7, 10),
            LocalDate.of(2025, 7, 11),
            // Random other holidays
            LocalDate.of(2025, 6, 17),
            LocalDate.of(2025, 8, 15)
    );
}
